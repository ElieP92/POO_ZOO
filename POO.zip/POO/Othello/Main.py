# Main script to test and instanciate our objects

from Engine import Engine
new_partie=Engine()
new_partie.tour_par_tour()