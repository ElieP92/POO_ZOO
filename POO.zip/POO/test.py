x1= input("c'est aux noirs :")
x1.split
ligne_index=int(x1[0])
col_index= int(x1[1])

board[ligne_index][col_index]=-1