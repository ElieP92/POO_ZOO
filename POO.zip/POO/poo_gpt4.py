class Board:
    def __init__(self, size=8):
        self.size = size
        self.board = [['.' for _ in range(size)] for _ in range(size)]

    def initialize(self):
        mid = self.size // 2
        self.board[mid - 1][mid - 1], self.board[mid][mid] = 'W', 'W'
        self.board[mid - 1][mid], self.board[mid][mid - 1] = 'B', 'B'

    def display(self):
        print("   ", " ".join(str(i) for i in range(1, self.size + 1)))
        for i, row in enumerate(self.board):
            print(i + 1, " ".join(row))

    def set_pawn(self, row, col, pawn):
        self.board[row][col] = pawn
pawn.py:
class Pawn:
    def __init__(self, color):
        self.color = color
        self.symbol = 'W' if color == 'white' else 'B'
game_engine.py:
from board import Board
from pawn import Pawn


class GameEngine:
    def __init__(self):
        self.board = Board()
        self.players = {'white': Pawn('white'), 'black': Pawn('black')}

    def is_valid_move(self, row, col, pawn):
        if not (0 <= row < self.board.size and 0 <= col < self.board.size):
            return False
        if self.board.board[row][col] != '.':
            return False

        directions = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]

        for dr, dc in directions:
            r, c = row + dr, col + dc
            if 0 <= r < self.board.size and 0 <= c < self.board.size and self.board.board[r][c] != pawn.symbol and self.board.board[r][c] != '.':
                while 0 <= r < self.board.size and 0 <= c < self.board.size and self.board.board[r][c] != '.':
                    if self.board.board[r][c] == pawn.symbol:
                        return True
                    r += dr
                    c += dc

        return False

    def apply_move(self, row, col, pawn):
        self.board.set_pawn(row, col, pawn.symbol)
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]

        for dr, dc in directions:
            r, c = row + dr, col + dc
            captured = []
            while 0 <= r < self.board.size and 0 <= c < self.board.size and self.board.board[r][c] != '.':
                if self.board.board[r][c] == pawn.symbol:
                    for cr, cc in captured:
                        self.board.set_pawn(cr, cc, pawn.symbol)
                    break
                captured.append((r, c))
                r += dr
                c += dc

    def play_game(self):
        self.board.initialize()
        turn = 'white'
        while True:
            self.board.display()
            print(turn, "player's turn")
            row = int(input("Enter row: ")) - 1
            col = int(input("Enter column: ")) - 1
            if self.is_valid_move(row, col, self.players[turn]):
                self.apply_move(row, col, self.players[turn])
                turn = 'black' if turn == 'white' else 'white'
            else:
                print("Invalid move, try again")


if __name__ == '__main__':
    game = GameEngine()
    game.play_game()